async function cotarDolar() {
  try {
    const resposta = await fetch('https://economia.awesomeapi.com.br/json/last/USD-BRL,EUR-BRL');
    const dados = await resposta.json();

    const valorAtual = parseFloat(dados.USDBRL.bid);
    const valorMaior = parseFloat(dados.USDBRL.high);
    const valorMenor = parseFloat(dados.USDBRL.low);
    const valorChance = parseFloat(dados.USDBRL.ask);

    const formatar = valor => valor.toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' });

    const container = document.getElementById('cotarDolar');
    container.innerHTML = `
      <strong>Cotação Atual:</strong> ${formatar(valorAtual)}<br>
      <strong>Maior do Dia:</strong> ${formatar(valorMaior)}<br>
      <strong>Menor do Dia:</strong> ${formatar(valorMenor)}<br>
      <strong>Valor de Venda:</strong> ${formatar(valorChance)}
    `;
  } catch (error) {
    document.getElementById('cotarDolar').innerText = 'Erro ao buscar cotação do dólar.';
    console.error('Erro ao buscar cotação:', error);
  }
}

async function carregarJogoDoMes() {
  try {
    const resposta = await fetch('http://localhost:3001/jogo-do-mes');
    const dados = await resposta.json();

    const jogo = dados.list[0]; // <- Aqui está o acesso correto!

    if (!jogo || !jogo.deal) {
      console.error('Jogo inválido ou sem deal:', jogo);
      return;
    }

    const titulo = jogo.title;
    const imagem = jogo.assets.banner300 || jogo.assets.banner145;
    const precoAtual = jogo.deal.price.amount;
    const precoAntigo = jogo.deal.regular.amount;
    const precoMaisBaixo = jogo.deal.historyLow.amount;
    const desconto = jogo.deal.cut;
    const link = jogo.deal.url;
    const plataforma = jogo.deal.shop.name || 'Outros';
    const tagHTML = `<span class="tag plataforma-${plataforma.toLowerCase()}">${plataforma}</span>`;
    const tagDesconto = `<span class="tag desconto">${desconto}% OFF</span>`;

    // Exibe no contêiner
    const container = document.getElementById('jogo-do-mes');
    container.innerHTML = `
      <img src="${imagem}" alt="${titulo}" />
      ${tagHTML}
      ${tagDesconto}
      <div>
        <h3>${titulo}</h3>
        <p><s>R$ ${precoAntigo}</s> → <strong>R$ ${precoAtual}</strong></p>
        <a class="btn" href="${link}" target="_blank">Ver Oferta</a>
      </div>
    `;

    // Renderiza gráfico
    renderizarGrafico(precoAntigo, precoAtual, precoMaisBaixo);

  } catch (error) {
    console.error('Erro ao carregar o jogo do mês:', error);
  }
}

document.addEventListener('DOMContentLoaded', carregarJogoDoMes);
document.addEventListener('DOMContentLoaded', cotarDolar);

