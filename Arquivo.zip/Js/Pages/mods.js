const BASE_URL = 'https://api.modrinth.com/v2';
let paginaAtual = 1;
let ModsPorPagina = definirQuantidadePorResolucao();
let todosMods = [];
async function carregarMods() {
  try {
    const resposta = await fetch('https://api.modrinth.com/v2/search?facets=[["project_type:mod"],["categories:fabric"]]&limit=100');
    const dados = await resposta.json();

    todosMods = dados.list || [];
    ModsFiltrados = [...todosMods];
    renderizarPagina(1);
    criarControlesPaginacao();
  } catch (error) {
    console.error('Erro ao carregar Mods:', error);
  }
}

function renderizarPagina(pagina) {
  const container = document.getElementById('mod-list');
  container.innerHTML = '';

  const inicio = (pagina - 1) * ModsPorPagina;
  const fim = inicio + ModsPorPagina;
  const Mods = ModsFiltrados.slice(inicio, fim);

  // Usa DocumentFragment para performance
  const fragment = document.createDocumentFragment();

  Mods.forEach(Mod => {
    const card = document.createElement('div');
    card.className = 'card';

    card.innerHTML = `
          ${mod.icon_url ? `<img src="${mod.icon_url}" alt="Logo de ${mod.title}">` : ''}
            <h2>${mod.title}</h2>
            <p>${mod.description}</p>
            <a class="btn btn-oferta" href="https://modrinth.com/mod/${mod.slug}" target="_blank">Ver no Modrinth</a>
    `;

    card.querySelector('.ver-oferta').addEventListener('click', () => abrirPopup(Mod));
    fragment.appendChild(card);
  });

  container.appendChild(fragment);
}
function criarControlesPaginacao() {
  const container = document.getElementById('paginacao');
  container.innerHTML = '';

  const totalPaginas = Math.ceil(ModsFiltrados.length / ModsPorPagina);

  const adicionarBotao = (pagina, texto = null, isAtivo = false) => {
    const btn = document.createElement('button');
    btn.className = 'btn';
    btn.textContent = texto || pagina;
    if (isAtivo) btn.classList.add('ativo');
    btn.onclick = () => {
      paginaAtual = pagina;
      renderizarPagina(pagina);
      criarControlesPaginacao();
    };
    container.appendChild(btn);
  };

  if (paginaAtual > 1) adicionarBotao(paginaAtual - 1, 'Anterior');

  adicionarBotao(1, '1', paginaAtual === 1);

  if (paginaAtual > 3) {
    const pontos = document.createElement('span');
    pontos.textContent = '...';
    container.appendChild(pontos);
  }

  for (let i = paginaAtual - 1; i <= paginaAtual + 1; i++) {
    if (i > 1 && i < totalPaginas) {
      adicionarBotao(i, i, paginaAtual === i);
    }
  }

  if (paginaAtual < totalPaginas - 2) {
    const pontos = document.createElement('span');
    pontos.textContent = '...';
    container.appendChild(pontos);
  }

  if (totalPaginas > 1) adicionarBotao(totalPaginas, totalPaginas, paginaAtual === totalPaginas);

  if (paginaAtual < totalPaginas) adicionarBotao(paginaAtual + 1, 'Próximo');
}
function definirQuantidadePorResolucao() {
  const largura = window.innerWidth;

  if (largura >= 1900) return 18;
  if (largura >= 1600) return 14;
  if (largura >= 1200) return 12;
  if (largura >= 768) return 8;
  return 4;
}
window.addEventListener('resize', () => {
  const novaQuantidade = definirQuantidadePorResolucao();
  if (ModsPorPagina !== novaQuantidade) {
    ModsPorPagina = novaQuantidade;
    renderizarPagina(paginaAtual);
    criarControlesPaginacao();
  }
});

document.addEventListener('DOMContentLoaded', () => {
  carregarMods();
});