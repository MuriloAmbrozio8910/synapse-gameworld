let paginaAtual = 1;
let ModsPorPagina = definirQuantidadePorResolucao();
let todosMods = [];
let ModsFiltrados = [];
let debounceTimer;
let tipo_mod = "mod";


function aplicarFiltros() {
  const nome = document.getElementById('filtro-nome').value.toLowerCase();
  const ordenacaoTipo = document.getElementById('filtro-ordenacao').value;

  jogosFiltrados = todosMods.filter(jogo =>
    jogo.title.toLowerCase().includes(nome)
  );

  switch (ordenacaoTipo) {
    case 'mod':
    case 'modpack':
    case 'shader':
    case 'resourcepack':
      tipo_mod = ordenacaoTipo; // <-- define o tipo de mod
      carregarMods();       // <-- recarrega com novo tipo
      return;               // sai para evitar re-renderização desnecessária
  }
  ModsFiltrados = todosMods.filter(jogo =>
    jogo.title.toLowerCase().includes(nome)
  );
  paginaAtual = 1;
  renderizarPagina(paginaAtual);
  criarControlesPaginacao();
}
async function carregarMods() {
  try {
    const url = `https://api.modrinth.com/v2/search?facets=[[%22project_type:${tipo_mod}%22],[%22categories:fabric%22]]&limit=1000`;
    const resposta = await fetch(url);
    const dados = await resposta.json();

    todosMods = dados.hits || [];
    ModsFiltrados = [...todosMods];
    renderizarPagina(1);
    criarControlesPaginacao();
  } catch (error) {
    console.error('Erro ao carregar Mods:', error);
  }
}

function renderizarPagina(pagina) {
  const container = document.getElementById('mod-list');
  container.innerHTML = '';

  const inicio = (pagina - 1) * ModsPorPagina;
  const fim = inicio + ModsPorPagina;
  const Mods = ModsFiltrados.slice(inicio, fim);

  // Usa DocumentFragment para performance
  const fragment = document.createDocumentFragment();

  Mods.forEach(Mod => {
    const card = document.createElement('div');
    card.className = 'card';
    let plataformasHTML = '';
    if (Array.isArray(Mod.categories)) {
      plataformasHTML = Mod.categories.map(cat => {
        return `<span class="tag">${cat}</span>`;
      }).join(' ');
    } else {
      plataformasHTML = '<span class="plataforma">Outros</span>';
    }
    card.innerHTML = `
        ${Mod.icon_url ? `<img src="${Mod.icon_url}" alt="Logo de ${Mod.title}">` : ''}
        <div class="tag-list">${plataformasHTML}</div>
        <h2>${Mod.title}</h2>
        <p>${Mod.description}</p>
        <a class="btn btn-oferta" href="https://modrinth.com/mod/${Mod.slug}" target="_blank">Ver no Modrinth</a>
    `;
    fragment.appendChild(card);
  });

  container.appendChild(fragment);
}
function criarControlesPaginacao() {
  const container = document.getElementById('paginacao');
  container.innerHTML = '';

  const totalPaginas = Math.ceil(ModsFiltrados.length / ModsPorPagina);

  const adicionarBotao = (pagina, texto = null, isAtivo = false) => {
    const btn = document.createElement('button');
    btn.className = 'btn';
    btn.textContent = texto || pagina;
    if (isAtivo) btn.classList.add('ativo');
    btn.onclick = () => {
      paginaAtual = pagina;
      renderizarPagina(pagina);
      criarControlesPaginacao();
    };
    container.appendChild(btn);
  };

  if (paginaAtual > 1) adicionarBotao(paginaAtual - 1, 'Anterior');

  adicionarBotao(1, '1', paginaAtual === 1);

  if (paginaAtual > 3) {
    const pontos = document.createElement('span');
    pontos.textContent = '...';
    container.appendChild(pontos);
  }

  for (let i = paginaAtual - 1; i <= paginaAtual + 1; i++) {
    if (i > 1 && i < totalPaginas) {
      adicionarBotao(i, i, paginaAtual === i);
    }
  }

  if (paginaAtual < totalPaginas - 2) {
    const pontos = document.createElement('span');
    pontos.textContent = '...';
    container.appendChild(pontos);
  }

  if (totalPaginas > 1) adicionarBotao(totalPaginas, totalPaginas, paginaAtual === totalPaginas);

  if (paginaAtual < totalPaginas) adicionarBotao(paginaAtual + 1, 'Próximo');
}
function definirQuantidadePorResolucao() {
  const largura = window.innerWidth;

  if (largura >= 1900) return 18;
  if (largura >= 1600) return 14;
  if (largura >= 1200) return 12;
  if (largura >= 768) return 8;
  return 4;
}
window.addEventListener('resize', () => {
  const novaQuantidade = definirQuantidadePorResolucao();
  if (ModsPorPagina !== novaQuantidade) {
    ModsPorPagina = novaQuantidade;
    renderizarPagina(paginaAtual);
    criarControlesPaginacao();
  }
});

document.addEventListener('DOMContentLoaded', () => {
  carregarMods();
    // Filtro de nome com debounce
  document.getElementById('filtro-nome').addEventListener('input', (e) => {
    clearTimeout(debounceTimer);
    debounceTimer = setTimeout(aplicarFiltros, 250);
  });

  // Filtro de ordenação
  document.getElementById('filtro-ordenacao').addEventListener('change', aplicarFiltros);
});