document.addEventListener('DOMContentLoaded', () => {
  carregarJogosGratis();
  carregarJogosDesconto();
  carregarModsPopulares();
});
let jogosFiltrados = [];
let paginaAtual = 1;
const jogosPorPagina = 8;
let todosJogos = [];

document.getElementById('filtro-nome').addEventListener('input', aplicarFiltros);
document.getElementById('filtro-ordenacao').addEventListener('change', aplicarFiltros);
function aplicarFiltros() {
  const nome = document.getElementById('filtro-nome').value.toLowerCase();
  const ordenacao = document.getElementById('filtro-ordenacao').value;

  jogosFiltrados = todosJogos.filter(jogo => {
    return jogo.title.toLowerCase().includes(nome);
  });

  switch (ordenacao) {
    case 'preco-menor':
      jogosFiltrados.sort((a, b) => a.deal.price.amount - b.deal.price.amount);
      break;
    case 'preco-maior':
      jogosFiltrados.sort((a, b) => b.deal.price.amount - a.deal.price.amount);
      break;
    case 'populares':
      jogosFiltrados.sort((a, b) => b.deal.rating - a.deal.rating); // exemplo com rating
      break;
    case 'novos':
      jogosFiltrados.sort((a, b) => new Date(b.timestamp) - new Date(a.timestamp)); // se tiver data
      break;
    case 'gratuitos':
      jogosFiltrados = jogosFiltrados.filter(jogo => jogo.deal.price.amount === 0);
      break;
  }

  paginaAtual = 1;
  renderizarPagina(paginaAtual);
  criarControlesPaginacao();
}

async function carregarJogosGratis() {
  try {
    const resposta = await fetch('http://localhost:3001/promocoes');
    const dados = await resposta.json();

    todosJogos = dados.list; // Salva todos os jogos globalmente
    jogosFiltrados = [...todosJogos]; // Inicializa com todos
    renderizarPagina(1);
    criarControlesPaginacao();
    renderizarPagina(paginaAtual);

  } catch (error) {
    console.error('Erro ao carregar jogos:', error);
  }
}

function renderizarPagina(pagina) {
  const container = document.getElementById('lista-jogos-com-desconto');
  container.innerHTML = '';

  const inicio = (pagina - 1) * jogosPorPagina;
  const fim = inicio + jogosPorPagina;
  const jogos = jogosFiltrados.slice(inicio, fim);

  jogos.forEach(jogo => {
    const card = document.createElement('div');
    card.classList.add('card');

    const titulo = jogo.title;
    const imagem = jogo.assets.banner300 || jogo.assets.banner145;
    const precoAntigo = jogo.deal.regular.amount.toFixed(2);
    const precoNovo = jogo.deal.price.amount.toFixed(2);
    const desconto = jogo.deal.cut;
    const linkOferta = jogo.deal.url;
    const plataforma = jogo.deal.shop.name || 'Outros';
    const tagHTML = `<span class="tag plataforma-${plataforma.toLowerCase()}">${plataforma}</span>`;
    const tagDesconto = `<span class="tag desconto">${desconto}% OFF</span>`;

    card.innerHTML = `
      <img src="${imagem}" alt="${titulo}" />
      ${tagHTML}
      ${tagDesconto}
      <div>
        <h3>${titulo}</h3>
        <p><s>R$ ${precoAntigo}</s> → <strong>R$ ${precoNovo}</strong></p>
        <a class="btn" href="${linkOferta}" target="_blank">Ver Oferta</a>
      </div>
    `;
    container.appendChild(card);
  });

  criarControlesPaginacao();
}

function criarControlesPaginacao() {
  const container = document.getElementById('paginacao');
  container.innerHTML = '';

  const totalPaginas = Math.ceil(todosJogos.length / jogosPorPagina);
  const maxExibir = 5; // Total máximo de páginas vizinhas (sem contar as fixas)

  const adicionarBotao = (pagina, texto = null, isAtivo = false) => {
    const btn = document.createElement('button');
    btn.classList.add('btn')
    btn.textContent = texto || pagina;
    if (isAtivo) btn.classList.add('ativo');
    btn.onclick = () => {
      paginaAtual = pagina;
      renderizarPagina(pagina);
    };
    container.appendChild(btn);
  };

  if (paginaAtual > 1) {
    adicionarBotao(paginaAtual - 1, 'Anterior');
  }

  // Sempre mostra a primeira página
  adicionarBotao(1, '1', paginaAtual === 1);

  // Mostra "..." se estiver longe da página 2
  if (paginaAtual > 3) {
    const pontos = document.createElement('span');
    pontos.textContent = '...';
    container.appendChild(pontos);
  }

  // Páginas ao redor da atual (ex: atual = 6 -> mostra 5,6,7)
  for (let i = paginaAtual - 1; i <= paginaAtual + 1; i++) {
    if (i > 1 && i < totalPaginas) {
      adicionarBotao(i, i, paginaAtual === i);
    }
  }

  // Mostra "..." se estiver longe do fim
  if (paginaAtual < totalPaginas - 2) {
    const pontos = document.createElement('span');
    pontos.textContent = '...';
    container.appendChild(pontos);
  }

  // Sempre mostra a última página
  if (totalPaginas > 1) {
    adicionarBotao(totalPaginas, totalPaginas, paginaAtual === totalPaginas);
  }

  if (paginaAtual < totalPaginas) {
    adicionarBotao(paginaAtual + 1, 'Próximo');
  }
}

function carregarModsPopulares() {
  // Exemplo de dados simulados
  const mods = [
    {
      nome: 'OptiFine para Minecraft',
      imagem: 'https://optifine.net/images/optifine.png',
      link: 'https://optifine.net/downloads'
    },
    {
      nome: 'SkyUI para Skyrim',
      imagem: 'https://staticdelivery.nexusmods.com/mods/110/images/3863-1-1353076680.jpg',
      link: 'https://www.nexusmods.com/skyrim/mods/3863'
    }
  ];

  const container = document.getElementById('lista-mods');
  mods.forEach(mod => {
    const card = document.createElement('div');
    card.classList.add('card');
    card.innerHTML = `
      <img src="${mod.imagem}" alt="${mod.nome}" />
      <h3>${mod.nome}</h3>
      <a href="${mod.link}" target="_blank">Download</a>
    `;
    container.appendChild(card);
  });
}