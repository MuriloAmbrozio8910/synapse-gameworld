const express = require('express');
const axios = require('axios');
const cors = require('cors');
const app = express();

app.use(cors());

const API_KEY = 'bc111ff70ce3ebaf6447395372d4f06d401d151f';

app.get('/promocoes', async (req, res) => {
  try {
    const response = await axios.get(`https://api.isthereanydeal.com/deals/v2`, {
      params: {
        key: API_KEY,
        region: 'br',
        country: 'BR',
        limit: 200,
        sort: '-trending'
      }
    });
    res.json(response.data);
  } catch (err) {
    console.error(err);
    res.status(500).send('Erro ao buscar promoções');
  }
});
app.get('/jogo-do-mes', async (req, res) => {
  try {
    const response = await axios.get(`https://api.isthereanydeal.com/deals/v2`, {
      params: {
        key: API_KEY,
        region: 'br',
        country: 'BR',
        limit: 1,
        sort: 'rank'
      }
    });
    res.json(response.data);
  } catch (err) {
    console.error(err);
    res.status(500).send('Erro ao buscar o jogo do mes');
  }
});

app.listen(3001, () => {
  console.log('Servidor rodando em http://localhost:3001');
});